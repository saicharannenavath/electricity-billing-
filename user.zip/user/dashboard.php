<?php
include '../config/db.php';
session_start();
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="../assets/style.css"></head>
<body>
    <div class="navbar"><h1>User Portal</h1></div>
    <div class="container">
        <h2>Find Your Bill</h2>
        <form action="view_bill.php" method="GET">
            <input type="text" name="service_number" placeholder="Enter Service Number" required>
            <button type="submit">View Bill Details</button>
        </form>
        <br>
        <button onclick="location.href='../index.php'">Home</button>
    </div>
</body>
</html>