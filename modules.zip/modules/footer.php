<?php
function renderFooter() {
    ?>
    </div>
    <footer style="text-align:center;padding:12px;color:#666;font-size:13px;">
        &copy; <?php echo date('Y'); ?> Electricity Billing System
    </footer>
    </body>
    </html>
    <?php
}
?>
