<?php
function renderHeader($title = 'Electricity Billing', $role = 'Portal') {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <link rel="stylesheet" href="/assets/style.css">
        <title><?php echo htmlspecialchars($title); ?></title>
    </head>
    <body>
    <div class="header-nav">
        <div class="nav-brand"><?php echo htmlspecialchars($title); ?></div>
        <div>
            <a href="/index.php">Home</a>
            <a href="/logout.php">Logout</a>
        </div>
    </div>
    <div class="container">
    <?php
}
?>
