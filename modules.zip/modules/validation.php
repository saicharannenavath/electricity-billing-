<?php
// Module: validation.php
// Exposes: validateName, validatePhone, sanitizeInput

function validateName($name) {
    return preg_match('/^[A-Za-z ]+$/', $name);
}

function validatePhone($phone) {
    return preg_match('/^[0-9]{10}$/', $phone);
}

function sanitizeInput($conn, $value) {
    return mysqli_real_escape_string($conn, trim($value));
}

?>
