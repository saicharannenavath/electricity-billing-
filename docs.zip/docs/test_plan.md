# Test Plan

## Overview
This test plan covers the key functional units in `modules/validation.php` and `modules/billing.php`.

### Test cases for `validateName` (Module: validation)
- Test ID: V-NAME-01
  - Functionality: Accepts alphabetic names with spaces
  - Input: "Alice Bob"
  - Expected Output: true

- Test ID: V-NAME-02
  - Functionality: Rejects numbers and special characters
  - Input: "Bob123" / "Anna@"
  - Expected Output: false

### Test cases for `validatePhone` (Module: validation)
- Test ID: V-PHONE-01
  - Functionality: Accepts exactly 10 digits
  - Input: "9876543210"
  - Expected Output: true

- Test ID: V-PHONE-02
  - Functionality: Rejects length != 10
  - Input: "12345" / "12345678901"
  - Expected Output: false

### Test cases for `calculateSlabBill` (Module: billing)
- Test ID: B-SLAB-01
  - Functionality: First slab computation
  - Input: 30 units
  - Expected Output: 30 * 1.5 = 45.00

- Test ID: B-SLAB-02
  - Functionality: Multiple slabs (e.g., 120 units)
  - Input: 120
  - Expected Output: (50*1.5) + (50*2.5) + (20*3.5) = 75 + 125 + 70 = 270.00

- Test ID: B-SLAB-03
  - Functionality: Beyond 150 units
  - Input: 200
  - Expected Output: (50*1.5)+(50*2.5)+(50*3.5)+(50*4.5) = 75+125+175+225 = 600.00

- Test ID: B-SLAB-04
  - Functionality: Zero units -> minimum charge
  - Input: 0
  - Expected Output: 25.00

### Test cases for `computeBillDetails`
- Test ID: B-COMP-01
  - Functionality: Compute units and amount between readings
  - Input: prev=100, curr=220
  - Expected Output: units=120, amount=270.00

### Test cases for DB pending lookup
- Test ID: B-PEND-01
  - Functionality: Sum unpaid bills for a service number
  - Input: a service number with known unpaid bills
  - Expected Output: Correct sum (depends on DB)


## Test Report
Run `php tests/test_billing.php` to execute the automated checks for compute functions. Record actual output and compare with expected outputs above and mark PASS/FAIL.
