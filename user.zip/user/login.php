<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="../assets/style.css"></head>
<body>
    <div class="container" style="max-width:500px; margin-top:100px;">
        <h2 style="text-align:center;">Consumer Portal</h2>
        <form action="view_bill.php" method="GET">
            <input type="text" name="service_number" placeholder="Enter Service Number" required>
            <button type="submit">View All Bills</button>
        </form>
        <p style="text-align:center;"><a href="../index.php">Back to Home</a></p>
    </div>
</body>
</html>