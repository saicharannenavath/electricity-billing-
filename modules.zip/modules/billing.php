<?php
// Module: billing.php
// Exposes: calculateSlabBill, computeBillDetails, getPreviousPending

function calculateSlabBill($units) {
    $units = intval($units);
    if ($units <= 0) {
        return 25.00;
    }

    $remaining = $units;
    $amount = 0.0;

    // First 50
    $take = min(50, $remaining);
    $amount += $take * 1.5;
    $remaining -= $take;

    // Second 50
    if ($remaining > 0) {
        $take = min(50, $remaining);
        $amount += $take * 2.5;
        $remaining -= $take;
    }

    // Third 50
    if ($remaining > 0) {
        $take = min(50, $remaining);
        $amount += $take * 3.5;
        $remaining -= $take;
    }

    // Beyond
    if ($remaining > 0) {
        $amount += $remaining * 4.5;
    }

    return round($amount, 2);
}

function computeBillDetails($prev_reading, $curr_reading) {
    $prev = intval($prev_reading);
    $curr = intval($curr_reading);
    $units = max(0, $curr - $prev);
    $amount = calculateSlabBill($units);
    $fine = 150.00;
    return array(
        'units' => $units,
        'amount' => $amount,
        'fine' => $fine,
        'amount_with_fine' => $amount + $fine
    );
}

function getPreviousPending($conn, $service_number) {
    $sn = mysqli_real_escape_string($conn, $service_number);
    $res = mysqli_query($conn, "SELECT SUM(amount) as pending FROM bills WHERE service_number='$sn' AND status='Unpaid'");
    $row = mysqli_fetch_assoc($res);
    return floatval($row['pending']);
}

?>
