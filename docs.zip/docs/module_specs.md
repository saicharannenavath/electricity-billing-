# Module Specifications

## modules/header.php
- Module Name: Header Renderer
- Input: `$title` (string), `$role` (string)
- Preconditions: None (should be included before output)
- Logic: Outputs the HTML document head, navigation bar and opens `.container` div.
- Output: HTML page header and opening container markup.

## modules/footer.php
- Module Name: Footer Renderer
- Input: None
- Preconditions: `modules/header.php` was used or a matching page structure.
- Logic: Outputs the closing `.container` and page footer, closing body/html tags.
- Output: HTML footer and closing tags.

## modules/validation.php
- Module Name: Validation Helpers
- Input: `validateName($name)`, `validatePhone($phone)`, `sanitizeInput($conn, $value)`
- Preconditions: When validating input from user forms.
- Logic: Uses regex to validate name (alphabets + spaces) and phone (10 digits). `sanitizeInput` trims and escapes for DB.
- Output: Boolean for validations; sanitized string for DB storage.

## modules/billing.php
- Module Name: Billing Logic
- Input: `calculateSlabBill($units)`, `computeBillDetails($prev, $curr)`, `getPreviousPending($conn, $service_number)`
- Preconditions: Readings are integers; DB connection available for pending lookup.
- Logic: Applies slab rates: first 50 @1.5, next 50 @2.5, next 50 @3.5, beyond @4.5; minimum charge ₹25 when units == 0; computes fine as ₹150.
- Output: Amount payable (float), unit counts and fine info.


