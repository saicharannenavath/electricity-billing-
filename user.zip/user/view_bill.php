<?php
include '../config/db.php';

if (!isset($_GET['service_number']) || empty($_GET['service_number'])) {
    die("<div class='container'><h2>Please enter a service number.</h2><button onclick='history.back()'>Back</button></div>");
}

$sn = mysqli_real_escape_string($conn, $_GET['service_number']);

// Fetch User Details
$user_query = "SELECT * FROM users WHERE service_number='$sn'";
$user_result = mysqli_query($conn, $user_query);
$user = mysqli_fetch_assoc($user_result);

if (!$user) { 
    die("<div class='container'><h2>Service Number Not Found</h2><button onclick='history.back()'>Back</button></div>"); 
}

// Fetch all bills for this user
$bill_query = "SELECT * FROM bills WHERE service_number='$sn' ORDER BY id DESC";
$bill_result = mysqli_query($conn, $bill_query);
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        /* Header Navigation Styles - Aligned Correctly */
        .header-nav { 
            background: #2c3e50; 
            padding: 15px 25px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            color: white; 
            margin-bottom: 20px;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .header-nav-links {
            display: flex;
            gap: 10px;
        }
        .header-nav a, .header-nav button { 
            color: white; 
            text-decoration: none; 
            background: transparent; 
            border: 1px solid white; 
            padding: 8px 20px; 
            cursor: pointer; 
            border-radius: 4px;
            font-size: 14px;
            font-weight: 600;
            transition: 0.3s;
        }
        .header-nav a:hover { background: rgba(255,255,255,0.1); }
        .nav-brand { font-size: 18px; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; }

        /* Bill Paper Styles */
        .bill-paper { 
            border: 2px solid #000; 
            padding: 30px; 
            margin-bottom: 40px; 
            background: #fff; 
            position: relative; 
            font-family: 'Courier New', Courier, monospace; 
            box-sizing: border-box;
        }
        .bill-header { border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px; text-align: center; }
        .bill-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        .details-label { font-weight: bold; text-transform: uppercase; font-size: 11px; color: #333; margin-bottom: 2px; }
        .details-value { font-size: 15px; margin-bottom: 15px; line-height: 1.2; }
        .amount-table { width: 100%; border-top: 2px solid #000; border-bottom: 2px solid #000; margin-top: 15px; border-collapse: collapse; }
        .status-stamp { position: absolute; top: 120px; right: 50px; border: 4px solid; padding: 10px; transform: rotate(-15deg); font-weight: bold; font-size: 32px; opacity: 0.2; z-index: 1; }
        .footer-note { font-size: 11px; margin-top: 20px; text-align: center; font-style: italic; color: #555; }
        .slab-breakdown { font-size: 12px; color: #666; margin-top: 10px; line-height: 1.5; border-top: 1px dashed #ccc; padding-top: 10px; }
        
        @media print { 
            .no-print { display: none !important; } 
            .container { width: 100%; max-width: 100%; padding: 0; margin: 0; }
            .bill-paper { border: 1px solid #000; margin: 0; page-break-after: always; } 
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-nav no-print">
            <div class="nav-brand">Consumer Portal</div>
            <div class="header-nav-links">
                <a href="login.php">Dashboard</a>
                <button onclick="window.print()" style="background: #27ae60; border-color: #27ae60;">Print Bill</button>
            </div>
        </div>

        <?php if(mysqli_num_rows($bill_result) > 0): ?>
            <?php while($bill = mysqli_fetch_assoc($bill_result)): ?>
                <div class="bill-paper">
                    <?php 
                        $status_color = ($bill['status'] == 'Paid') ? '#27ae60' : '#c0392b';
                        $consumption = $bill['curr_reading'] - $bill['prev_reading'];
                        $type = $user['type'];
                    ?>
                    <div class="status-stamp" style="color: <?php echo $status_color; ?>; border-color: <?php echo $status_color; ?>;">
                        <?php echo strtoupper($bill['status']); ?>
                    </div>

                    <div class="bill-header">
                        <h1 style="margin:0; letter-spacing: 2px;">ELECTRICITY BOARD</h1>
                        <p style="margin:5px 0; font-weight: bold;">INVOICE FOR ELECTRICITY CONSUMPTION</p>
                    </div>

                    <div class="bill-grid">
                        <div style="text-align: left;">
                            <div class="details-label">Consumer Name</div>
                            <div class="details-value"><strong><?php echo htmlspecialchars($user['name']); ?></strong></div>

                            <div class="details-label">Address</div>
                            <div class="details-value">
                                <?php echo htmlspecialchars($user['address']); ?><br>
                                PINCODE: <?php echo htmlspecialchars($user['pincode']); ?>
                            </div>

                            <div class="details-label">Contact</div>
                            <div class="details-value"><?php echo htmlspecialchars($user['phone']); ?></div>
                        </div>
                        <div style="text-align: right;">
                            <div class="details-label">Service Number</div>
                            <div class="details-value"><strong><?php echo $user['service_number']; ?></strong></div>

                            <div class="details-label">Billing Period</div>
                            <div class="details-value"><?php echo htmlspecialchars($bill['billing_period']); ?></div>

                            <div class="details-label">Due Date</div>
                            <div class="details-value" style="color:#c0392b; font-weight: bold;">
                                <?php echo date("d-M-Y", strtotime($bill['due_date'])); ?>
                            </div>
                        </div>
                    </div>

                    <table class="amount-table">
                        <tr>
                            <td style="padding:20px; vertical-align: top; border-right: 1px solid #000;">
                                <div class="details-label">Connection Type</div>
                                <div class="details-value"><?php echo strtoupper($type); ?></div>
                                
                                <div class="details-label">Meter Readings</div>
                                <div class="details-value">
                                    Initial: <?php echo $bill['prev_reading']; ?> | Final: <?php echo $bill['curr_reading']; ?>
                                </div>
                                
                                <div class="details-label">Total Units Consumed</div>
                                <div class="details-value"><strong><?php echo $consumption; ?> Units</strong></div>

                                <div class="slab-breakdown">
                                    <strong>Tariff Details:</strong><br>
                                    <?php if($consumption <= 0): ?>
                                        Fixed Maintenance Charges Applied: ₹150.00
                                    <?php elseif($type == 'household'): ?>
                                        0-200 Units @ ₹8.00 / 201-450 @ ₹12.00 / 451+ @ ₹18.00
                                    <?php elseif($type == 'commercial'): ?>
                                        Commercial Flat Rate: ₹5.00 per unit
                                    <?php else: ?>
                                        Industrial Flat Rate: ₹3.00 per unit
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td style="text-align:right; padding:20px; background: #fdfdfd; width: 35%; vertical-align: top;">
                                <div class="details-label">Total Amount Payable</div>
                                <div style="font-size: 34px; font-weight: bold; color: #000; margin-top: 10px;">
                                    ₹<?php echo number_format($bill['amount'], 2); ?>
                                </div>
                                <div class="details-label" style="margin-top: 15px; font-size: 9px;">Inclusive of all applicable taxes</div>
                            </td>
                        </tr>
                    </table>

                    <div class="footer-note">
                        This is a computer-generated document. No signature is required.<br>
                        Category: <?php echo strtoupper($type); ?> | Service: Electricity Board
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="bill-paper" style="text-align:center;">
                <h3>No records found.</h3>
                <a href="login.php" class="no-print" style="color: #3498db; text-decoration: none;">Return to Search</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>